import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  template: `
  <h1>Login</h1>
  <form #loginform="ngForm" (ngSubmit)="onSubmit(loginform.value)">
  <input type="text" name="userid" placeholder="user id" ngModel required><br>
  <input type="password" name="pass" placeholder="password" ngModel required><br>
  <input type="submit" value="Login" [disabled]="loginform.invalid">
  </form>
  <button (click)="logout()">Logout</button>

  `,
  styles: [
  ]
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  onSubmit(login:any){
    if(login.userid=='kiran' && login.pass=='12345'){
      alert('login success')
      localStorage.setItem('user',login.userid);
    }
    else{
      alert('invalid attempt');
      //console.log(login);
    }
   
  }
  logout(){
    localStorage.removeItem('user');
  }

}
