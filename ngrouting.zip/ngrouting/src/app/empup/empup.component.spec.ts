import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpupComponent } from './empup.component';

describe('EmpupComponent', () => {
  let component: EmpupComponent;
  let fixture: ComponentFixture<EmpupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
