import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empup',
  template: `
    <p>
      empup works!
    </p>
  `,
  styles: [
  ]
})
export class EmpupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
