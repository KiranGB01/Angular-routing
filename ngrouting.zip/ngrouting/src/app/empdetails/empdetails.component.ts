import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-empdetails',
  template: `
 
  <h4>
  Empdetails of {{emps.name}}

<ul>
  <li>{{emps.id}}</li>
  <li>{{emps.name}}</li>
  <li>{{emps.sal}}</li>
  
</ul>
  <a routerLink="/emp">Back</a>

  `,
  styles: [
  ]
})
export class EmpdetailsComponent implements OnInit {
  id:number;
  emps:any;
  constructor(ar:ActivatedRoute,private es:EmpService) { 
   
   this.id=ar.snapshot.params.id;
    es.getEmp(this.id).subscribe(e=>this.emps=e);
  }

  ngOnInit(): void {
  }
  

}
