import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-empdelete',
  template: `
  <!--<form [formGroup]="emprform" (ngSubmit)="onSubmit()">
  <input type="number" name="id" placeholder="emp id" formControlName="id" required><br>
  <input type="text" name="name" placeholder="emp name" formControlName="name" required><br>
  <input type="number" name="sal" placeholder="emp sal" formControlName="sal" required><br>
  <input type="submit" value="delete" [disabled]="emprform.invalid">
</form>-->
<h2>Do you want to the details of employee id {{id}}</h2>
<ol *ngIf="emp">
   <li>{{emp.name}}</li>
   <li>{{emp.sal}}</li>
</ol>
<button (click)="delete()" style="background-color:red">yes</button>
  `,
  styles: [
  ]
})
export class EmpdeleteComponent implements OnInit {
  emprform:FormGroup;
  id:number;
  emp:any;
  constructor(ar:ActivatedRoute,private es:EmpService) {
    this.id=ar.snapshot.params.id;

    this.emprform=new FormGroup({
      id:new FormControl(this.id),
      name:new FormControl(),
      sal:new FormControl()
    });
  //  es.getEmployee(this.id).subscribe(e=>{this.emprform.setValue(e)});
  es.getEmployee(this.id).subscribe(e=>{this.emp=e});
   }

  ngOnInit(): void {
  }
  onSubmit(){
    this.es.delEmployee(this.id).subscribe(e=>{console.log(e);alert("Do you want to delete the data")});
  }
  delete(){
    if(confirm("Are you still sure?"))
    this.es.delEmployee(this.id).subscribe(e=>{console.log(e)});
  }

}
