import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { EmpComponent } from './emp/emp.component';
import { EmpdetailsComponent } from './empdetails/empdetails.component';
import { BookComponent } from './book/book.component';
import { BookdetailsComponent } from './bookdetails/bookdetails.component';
import { PnfComponent } from './pnf/pnf.component';
import {HttpClientModule} from '@angular/common/http';
import { EmpupComponent } from './empup/empup.component';
import {FormsModule, ReactiveFormsModule}from '@angular/forms';
import { EmpupdateComponent } from './empupdate/empupdate.component';
import { EmpdeleteComponent } from './empdelete/empdelete.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    EmpComponent,
    EmpdetailsComponent,
    BookComponent,
    BookdetailsComponent,
    PnfComponent,
    EmpupComponent,
    EmpupdateComponent,
    EmpdeleteComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
