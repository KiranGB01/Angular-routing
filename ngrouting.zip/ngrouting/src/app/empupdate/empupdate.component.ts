import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-empupdate',
  template: `
  <form [formGroup]="emprform" (ngSubmit)="onSubmit(emprform.value)">
      <input type="number" name="id" placeholder="emp id" formControlName="id" required><br>
      <input type="text" name="name" placeholder="emp name" formControlName="name" required><br>
      <input type="number" name="sal" placeholder="emp sal" formControlName="sal" required><br>
      <input type="submit" [disabled]="emprform.invalid">
    </form>
  `,
  styles: [
  ]
})
export class EmpupdateComponent implements OnInit {
  emprform:FormGroup;
  id:number;
  constructor(ar:ActivatedRoute,private es:EmpService,private router:Router) {
    this.id=ar.snapshot.params.id;
    
    this.emprform=new FormGroup({
      id:new FormControl(this.id),
      name:new FormControl(),
      sal:new FormControl()
    });
    es.getEmployee(this.id).subscribe(e=>{this.emprform.setValue(e)});
   }

  ngOnInit(): void {
  }
  onSubmit(emp:any){
    this.es.putEmployee(this.id,emp).subscribe(e=>{console.log(e);
      alert('Updated');
      this.router.navigate(['/emp']);
    });
}
}
