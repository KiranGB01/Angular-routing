import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmpService {
 
apiurl:string='http://localhost:36089/api/empasync/';
  constructor(private http:HttpClient) { }

  getEmps(){
    return this.http.get('http://localhost:36089/api/empasync');
  }

  getEmp(id:number){
    return this.http.get('http://localhost:36089/api/empasync/'+id);
  }

  saveData(emp:any){
    return this.http.post('http://localhost:36089/api/empasync',emp);
  }
  putEmployee(id:number,emp:any){
    return this.http.put(this.apiurl+id,emp);
    
  }
  getEmployee(id:number){
    return this.http.get(this.apiurl+id);
  }
  delEmployee(id:number){
    return this.http.delete(this.apiurl+id);
  }
}
