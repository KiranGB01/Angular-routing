import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import {UsersService} from '../users.service';

@Component({
  selector: 'app-book',
  template: `
   <h2>Book</h2>
   <!--<a routerLink="/book/1">1st Book</a><br>
   <a routerLink="/book/2">2nd Book</a>-->
   <table>
   <tr *ngFor="let u of users">
   <td>{{u.id}}</td>
   <td><a routerLink="/book/{{u.id}}">{{u.name}}</a></td>
   </tr>
   </table>
  `,
  styles: [
  ]
})
export class BookComponent implements OnInit {
  users:any;

  constructor(us:UsersService) { 
   us.getUsers().subscribe(u=>this.users=u);
  }

  ngOnInit(): void {
  }

}
