import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookComponent } from './book/book.component';
import { BookdetailsComponent } from './bookdetails/bookdetails.component';
import { EmpComponent } from './emp/emp.component';
import { EmpdeleteComponent } from './empdelete/empdelete.component';
import { EmpdetailsComponent } from './empdetails/empdetails.component';
import { EmpupComponent } from './empup/empup.component';
import { EmpupdateComponent } from './empupdate/empupdate.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PnfComponent } from './pnf/pnf.component';
import {AuthGuard} from './auth.guard';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'book',component:BookComponent},
  {path:'book/:id',component:BookdetailsComponent},
  {path:'emp',component:EmpComponent,canActivate:[AuthGuard]},
  {path:'emp/:id',component:EmpdetailsComponent},
  {path:'empupdate/:id',component:EmpupdateComponent},
  {path:'empdelete/:id',component:EmpdeleteComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'**',component:PnfComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
