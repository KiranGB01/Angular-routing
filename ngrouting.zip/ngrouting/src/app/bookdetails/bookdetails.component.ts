
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-bookdetails',
  template: `
    <h4>
      bookdetails of {{id}}
    </h4>
    <ul>
      <li>{{user.id}}</li>
      <li>{{user.name}}</li>
      <li>{{user.email}}</li>
      <li>{{user.phone}}</li>
      <li>{{user.website}}</li>
      <li>{{user.company.name}}</li>
    </ul>
  `,
  styles: [
  ]
})
export class BookdetailsComponent implements OnInit {
  id:number;
  user:any;
  constructor(ar:ActivatedRoute,us:UsersService) {
    this.id=ar.snapshot.params.id;
    us.getUser(this.id).subscribe(u=>this.user=u);
   }

  ngOnInit(): void {
  }

}
