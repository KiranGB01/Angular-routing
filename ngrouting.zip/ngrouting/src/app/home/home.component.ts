import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
   <h2>Home</h2>
   <h1>ABC is good company</h1>
  `,
  styles: [
  ]
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
