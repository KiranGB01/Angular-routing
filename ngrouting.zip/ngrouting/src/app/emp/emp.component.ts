import { Component, OnInit } from '@angular/core';
import {EmpService} from '../emp.service';

@Component({
  selector: 'app-emp',
  template: `
   <h3> Employees</h3>  
   <h3>Update data</h3> 
   <a routerLink="/emp/empup">update data </a>
    <form #empform2='ngForm' (ngSubmit)="onSubmit(empform2.value)">
      <input type="text" name="name" placeholder="ename" ngModel required><br>
      <input type="number" name="sal" placeholder="sal" ngModel required><br>
      <input type="submit" [disabled]="empform2.invalid">
    </form>
   <table>
   <tr *ngFor="let e of emps">
   <td>{{e.id}}</td>
   <td><a routerLink="/emp/{{e.id}}">{{e.name}}</a></td>
   <td><a routerLink="/empupdate/{{e.id}}">update</a></td>
   <td><a routerLink="/empdelete/{{e.id}}">delete</a></td>
   
   </tr>
   
  `,
  styles: [
  ]
})
export class EmpComponent implements OnInit {
  emps:any;
  constructor(private es:EmpService) { 
  
    es.getEmps().subscribe(u=>this.emps=u)
  }

  ngOnInit(): void {
  }
  onSubmit(emp:any){
    console.log(emp);
    this.es.saveData(emp).subscribe(e=>{console.log(e);this.emps.push(e)});
  }
}
